import pygui  # import the gui module

# -----------------------------------------------------------------------------------
#                                 EVENT/CALLBACK FUNCTIONS
# -----------------------------------------------------------------------------------
def onButtonClicked():
    print "Button clicked"

def onCheckBoxClicked():
    print "Checkbox clicked"

def onRadioButtonClicked():
    print "Radio clicked"

def onSpinBoxValueChanged():
    print window.spinBox.value()

def onComboBoxChanged():
    print window.comboBox.currentText()
    print window.comboBox.currentIndex()

def onDoubleSpinBoxValueChanged():
    print window.doubleSpinBox.value()


# -----------------------------------------------------------------------------------
#                                 BASIC CONTROL
# -----------------------------------------------------------------------------------

# load the window (form/widget) from UI file:
# the compoments put on the form in designer as mapped by their name 
# as attributes of returned window object. (e.g. if the button with name pushButton is 
# placed on the form, it's accessible via window.pushButton)
window = pygui.loadFromUiFile("scripts/form.ui")
window.show()
#window.hide()

# Label example:
window.label.setText("Test label")
print window.label.text()

# Button example:
window.pushButton.setText("Start")
print window.pushButton.text()
window.pushButton.clicked = onButtonClicked  # register function to be called when button is clicked

# LineEdit example:
window.lineEdit.setText("Text")
print window.lineEdit.text()

# Checkbox example:
window.checkBox.setText("Test Check Box")
print window.checkBox.text()
window.checkBox.setChecked(True)
print window.checkBox.isChecked()
window.checkBox.clicked = onCheckBoxClicked

# RadioButton example:
window.radioButton.setText("Test Check Box")
print window.radioButton.text()
window.radioButton.setChecked(True)
print window.radioButton.isChecked()
window.radioButton.clicked = onRadioButtonClicked

# SpinBox example:
window.spinBox.setMaximum(100) # set maximum possible value to set
window.spinBox.setMinimum(0) # set minimum possible value to set
window.spinBox.setValue(12) # set value of spin box
print window.spinBox.value() # get value of spin box
window.spinBox.changed = onSpinBoxValueChanged # register function that is called when value of spinbox changes

# DoubleSpinBox example:
window.doubleSpinBox.setMaximum(100.5) # set maximum possible value to set
window.doubleSpinBox.setMinimum(0.5) # set minimum possible value to set
window.doubleSpinBox.setValue(13.3) # set value of spin box
print window.doubleSpinBox.value() # get value of spin box
window.doubleSpinBox.changed = onDoubleSpinBoxValueChanged # register function that is called when value of double spinbox changes

# ComboBox example:
items = ["Item A", "ItemB"]
window.comboBox.setItems(items)
print window.comboBox.currentIndex()
print window.comboBox.currentText()
window.comboBox.setCurrentIndex(1)
window.comboBox.changed = onComboBoxChanged # register function that is called when combobox selected item changes

