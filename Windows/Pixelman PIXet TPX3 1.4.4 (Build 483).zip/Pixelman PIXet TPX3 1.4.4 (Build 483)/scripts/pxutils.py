VOLT1="Voltage1"
VOLT2="Voltage2"
VOLTSENSE1="VoltageSense1"
VOLTSENSE2="VoltageSense2"
CURSENSE1="CurrentSense1"
CURSENSE2="CurrentSense2"
MINVOLTAGE1="MinVoltage1"
MINVOLTAGE2="MinVoltage2"
MAXVOLTAGE1="MaxVoltage1"
MAXVOLTAGE2="MaxVoltage2"

pixet = None

class HV(object):

    def __init__(self, device):
        super(HV, self).__init__()
        self.device = device
        self.pars = device.parameters()

    def setVoltage(self, index, voltage):
        if index == 0:
            return self.pars.get(VOLT1).setI16(voltage)
        else:
            return self.pars.get(VOLT2).setI16(voltage)

    def getVoltage(self, index):
        if index == 0:
            return self.pars.get(VOLT1).getI16()
        else:
            return self.pars.get(VOLT2).getI16()

    def senseVoltage(self, index):
        if index == 0:
            return self.pars.get(VOLTSENSE1).getI32()
        else:
            return self.pars.get(VOLTSENSE2).getI32()

    def senseCurrent(self, index):
        if index == 0:
            return float(self.pars.get(CURSENSE1).getI32()) / 1000.0
        else:
            return float(self.pars.get(CURSENSE2).getI32()) / 1000.0

    def minVoltage(self, index):
        if index == 0:
            return self.pars.get(MINVOLTAGE1).getI32()
        else:
            return self.pars.get(MINVOLTAGE2).getI32()

    def maxVoltage(self, index):
        if index == 0:
            return self.pars.get(MAXVOLTAGE1).getI32()
        else:
            return self.pars.get(MAXVOLTAGE2).getI32()


def getHV(index):
    devices = pixet.devicesByType(pixet.PX_DEVTYPE_AUX)
    if not devices:
        print "No HV devices connected"
        return None
    if index < len(devices):
        return HV(devices[index])
    else:
        print "Invalid index for HV device"
        return None

def getMpxDevice(index):
    devices = pixet.devicesByType(pixet.PX_DEVTYPE_MPX2)
    if not devices:
        print "No devices connected"
        return None
    if index > len(devices):
        print "Invalid index for device"
        return None
    return devices[index]

def init(_pixet):
    global pixet
    pixet = _pixet
