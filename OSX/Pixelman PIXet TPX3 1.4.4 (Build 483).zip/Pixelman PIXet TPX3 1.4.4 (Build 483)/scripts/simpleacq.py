
# first list all Medipix/Timepix devices and use the first one:
devices = pixet.devicesByType(pixet.PX_DEVTYPE_MPX2)
if not devices:
    raise "No devices connected"

device = devices[0] # use  the first device

#  take 10 frames from the device, 0.5 second long and save to file test.pmf
for i in range(10):
    acqCount = 1
    acqTime = 0.5 # in seconds, half second
    outputFile = "test.pmf"
    device.doSimpleAcquisition(acqCount, acqTime, pixet.PX_FTYPE_AUTODETECT, outputFile)
